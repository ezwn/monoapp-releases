"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.virtualPathToFileSystemPath = exports.extractPostfixedVirtualFilePath = exports.extractVirtualFilePath = void 0;
const extractVirtualFilePath = (req) => decodeURIComponent(req.path.substring(1));
exports.extractVirtualFilePath = extractVirtualFilePath;
const extractPostfixedVirtualFilePath = (req, postfix) => {
    const postfixedVirtualPath = (0, exports.extractVirtualFilePath)(req);
    return postfixedVirtualPath.substring(0, postfixedVirtualPath.length - postfix.length);
};
exports.extractPostfixedVirtualFilePath = extractPostfixedVirtualFilePath;
const virtualPathToFileSystemPath = (path, config) => `${config.dataPath}${path}`;
exports.virtualPathToFileSystemPath = virtualPathToFileSystemPath;
