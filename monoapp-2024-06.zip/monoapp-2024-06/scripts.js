"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const child_process_1 = require("child_process");
const virtualPath_1 = require("./virtualPath");
const common_1 = require("./common");
function prefixLines(str, prefix) {
    return str
        .split('\n')
        .map((line) => `${prefix}${line}`)
        .join('\n');
}
function addScriptSupport(server, serverConfig) {
    server.post('*/executeSystemScript', (req, res) => {
        const virtualPath = (0, virtualPath_1.extractPostfixedVirtualFilePath)(req, '/executeSystemScript');
        (0, common_1.logDebug)();
        (0, common_1.logDebugVirtualPathHandler)('executeSystemScript', virtualPath);
        const fileFsPath = (0, virtualPath_1.virtualPathToFileSystemPath)(virtualPath, serverConfig);
        const script = `cd "${fileFsPath}"\n${req.body}`;
        (0, common_1.logDebug)(prefixLines(script, ' > '));
        (0, child_process_1.exec)(script, (error, stdout, stderr) => {
            if (error !== null) {
                console.log(`exec error: ${error}`);
                res.send(stderr);
            }
            else {
                res.send(stdout);
            }
        });
        (0, common_1.logDebug)();
    });
}
exports.default = addScriptSupport;
