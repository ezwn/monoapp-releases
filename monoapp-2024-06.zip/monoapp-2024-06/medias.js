"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.fixMediaFileName = void 0;
const multer_1 = __importDefault(require("multer"));
const fs_1 = __importDefault(require("fs"));
const virtualPath_1 = require("./virtualPath");
const common_1 = require("./common");
const imageExtensions = ['.jpg', '.jpeg', '.png'];
const audioExtensions = ['.mp3', '.m4b'];
const videoExtensions = ['.avi', '.mp4', '.wmv', '.mkv'];
const knownExtensions = [
    ...audioExtensions,
    ...videoExtensions,
    ...imageExtensions
];
const unwantedSubstrings = [
    'Official Music Video',
    'Official Video',
    'BDRip',
    'DVDRip',
    'XviD',
    'X264'
];
const tmpDir = '.tmp';
const fixMediaFileName = (filename) => {
    const knownExtension = knownExtensions.find((ext) => filename.endsWith(ext));
    if (knownExtension) {
        const name = filename.substring(0, filename.length - knownExtension.length);
        let lematizedName = name
            .replace(/[_.]/g, ' ')
            .replace(/([^ ])[-]([^ ])/g, '$1 $2')
            .toLocaleLowerCase()
            .trim()
            .replace(/[^A-Za-zÀ-ÿ0-9][A-Za-zÀ-ÿ]/g, (c) => c.toUpperCase())
            .replace(/[^.]/, (c) => c.toUpperCase());
        unwantedSubstrings.forEach((sentence) => (lematizedName = lematizedName.replace(sentence, '')));
        return lematizedName.replace(/[ ]+/, ' ').trim() + knownExtension;
    }
    else {
        return filename;
    }
};
exports.fixMediaFileName = fixMediaFileName;
function addMediaSupport(server, serverConfig) {
    const upload = (0, multer_1.default)({ dest: `${serverConfig.dataPath}/${tmpDir}` });
    server.post('*/uploadFile', upload.single('file'), (req, res) => {
        const virtualPath = (0, virtualPath_1.extractPostfixedVirtualFilePath)(req, '/uploadFile');
        (0, common_1.logDebugVirtualPathHandler)('uploadFile', virtualPath);
        const pathTokens = virtualPath.split('/');
        const fileName = pathTokens[pathTokens.length - 1];
        const targetpath = virtualPath.substring(0, virtualPath.length - fileName.length - 1);
        const fixedFileName = (0, exports.fixMediaFileName)(fileName);
        const { path: tmpPath } = req.file;
        fs_1.default.rename(tmpPath, (0, virtualPath_1.virtualPathToFileSystemPath)(`${targetpath}/${fixedFileName}`, serverConfig), () => {
            console.log(`${fixedFileName} ready.`);
            res.sendStatus(200);
        });
    });
}
exports.default = addMediaSupport;
