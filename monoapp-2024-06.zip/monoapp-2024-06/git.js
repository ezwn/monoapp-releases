"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.commitFile = void 0;
const path_1 = __importDefault(require("path"));
const child_process_1 = require("child_process");
function checkIfGitRepo(path) {
    return new Promise((resolve) => {
        (0, child_process_1.exec)(`cd "${path}"\ngit rev-parse --is-inside-work-tree`, (error, stdout, stderr) => {
            if (error) {
                console.error(`exec error: ${error}`);
                return resolve(false);
            }
            if (stderr) {
                console.error(`stderr: ${stderr}`);
                return resolve(false);
            }
            // stdout should be "true\n" for a git repo
            resolve(stdout.trim() === 'true');
        });
    });
}
function commitFile(filePath, message) {
    const parentPath = path_1.default.dirname(filePath);
    const fileName = path_1.default.basename(filePath);
    checkIfGitRepo(parentPath).then((isRepo) => {
        if (isRepo) {
            const script = `cd "${parentPath}"\ngit add "${fileName}"\ngit commit -m "${message}"`;
            (0, child_process_1.exec)(script, (error) => {
                if (error !== null) {
                    console.log(`exec error: ${error}`);
                }
            });
        }
    });
}
exports.commitFile = commitFile;
