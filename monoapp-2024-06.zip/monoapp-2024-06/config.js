"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getConfig = void 0;
const dotenv_1 = __importDefault(require("dotenv"));
const os_1 = __importDefault(require("os"));
const path_1 = __importDefault(require("path"));
dotenv_1.default.config({ path: `.env.${process.env.NODE_ENV}` });
const { BE_PORT, BE_DATAPATH, BE_STATICS } = process.env;
const port = parseInt(BE_PORT || '8989', 10);
const dataPath = BE_DATAPATH || '~/MonoAppNotes';
const staticPath = BE_STATICS || __dirname + '/public';
const userHomeDir = os_1.default.homedir();
const effiRepoDir = path_1.default.dirname(path_1.default.dirname(path_1.default.dirname(path_1.default.dirname(__dirname))));
const getConfig = () => {
    const rawServerConfig = { port, dataPath, staticPath };
    return Object.assign(Object.assign({}, rawServerConfig), { dataPath: rawServerConfig.dataPath
            .replace(/~/g, userHomeDir)
            .replace(/EFFI_REPO_DIR/g, effiRepoDir), staticPath: rawServerConfig.staticPath
            .replace(/~/g, userHomeDir)
            .replace(/EFFI_REPO_DIR/g, effiRepoDir) });
};
exports.getConfig = getConfig;
