"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.logDebugVirtualPathHandler = exports.logDebug = void 0;
function logDebug(message) {
    console.log(message || '');
}
exports.logDebug = logDebug;
function logDebugVirtualPathHandler(methodName, virtualPath) {
    logDebug(`${methodName}(${virtualPath})`);
}
exports.logDebugVirtualPathHandler = logDebugVirtualPathHandler;
