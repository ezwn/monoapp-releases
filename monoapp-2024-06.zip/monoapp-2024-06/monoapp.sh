#! /bin/sh
cd /opt/monoapp
node index.js&

